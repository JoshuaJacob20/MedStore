package com.mashup.medstore.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.mashup.medstore.Models.Product_new;
public interface ProductnewRepository extends JpaRepository<Product_new, Integer>{

}