package com.mashup.medstore.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.mashup.medstore.Models.User;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByEmail(String email);
    User findByToken(String token);
    boolean existsByToken(String token);
}