package com.mashup.medstore.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.data.repository.query.Param;
import com.mashup.medstore.Models.Product;
import org.springframework.web.bind.annotation.ResponseBody;
import com.mashup.medstore.Repository.ProductRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ProductController {

    @Autowired
    private ProductRepository productRepository;

    @GetMapping("/create")
    public String createAction(Model model) {
        model.addAttribute("message", "Please enter the details below");
        return "create";
    }

    @PostMapping("/create")
    public String createActionProcess(Product productData, Model model) {
    	long productCount = productRepository.count();
    	if (productCount >= 5) {
    		model.addAttribute("message", "Sorry You Cannot add more than 5 Medicines!");
            return "create";
        }
        productRepository.save(productData);
        model.addAttribute("message", "The medicine " + productData.getName() + " with available stock of " + productData.getPrice() + " has been added successfully");
        return "create";
    }

//    @GetMapping("/all")
//    public String getAllProducts(Model model, @Param("keyword") String keyword) {
//        List<Product> products;
//        if (keyword != null && !keyword.isEmpty()) {
//            products = productRepository.findAllByKeyword(keyword);
//        } else {
//            products = productRepository.findAll();
//        }
//        model.addAttribute("products", products);
//        return "list";
//    }
    @GetMapping("/all")
    public String getAllProducts(Model model, 
                                 @RequestParam(defaultValue = "1") int page, 
                                 @RequestParam(defaultValue = "3") int size, 
                                 @Param("keyword") String keyword) {

        Pageable pageable = PageRequest.of(page - 1, size);
        Page<Product> productPage;

        if (keyword != null && !keyword.isEmpty()) {
            productPage = productRepository.findAllByKeyword(keyword, pageable);
        } else {
            productPage = productRepository.findAll(pageable);
        }

        model.addAttribute("products", productPage.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", productPage.getTotalPages());
        model.addAttribute("keyword", keyword);

        return "list"; // Thymeleaf template
    }

    @GetMapping("/update/{id}")
    public String updateProduct(@PathVariable Integer id, Model model) {
        Optional<Product> optionalProductDetails = productRepository.findById(id);
        if (optionalProductDetails.isPresent()) {
            model.addAttribute("productDetails", optionalProductDetails.get());
            return "update";
        }
        return "redirect:/all"; // Handle not found case
    }

    @PostMapping("/update/{id}")
    public String updateProduct(@PathVariable Integer id, Product productData) {
        Optional<Product> optionalProductDetails = productRepository.findById(id);
        if (optionalProductDetails.isPresent()) {
            Product productDetails = optionalProductDetails.get();
            productDetails.setName(productData.getName());
            productDetails.setDescription(productData.getDescription());
            productDetails.setExpirydate(productData.getExpirydate());
             productDetails.setPrice(productData.getPrice());
            productRepository.save(productDetails);
        }
        return "redirect:/all";
    }

    @GetMapping("/delete/{id}")
    public String deleteProduct(@PathVariable Integer id, Model model) {
        Optional<Product> optionalProductDetails = productRepository.findById(id);
        if (optionalProductDetails.isPresent()) {
            model.addAttribute("productDetails", optionalProductDetails.get());
            return "delete";
        }
        return "redirect:/all"; // Handle not found case
    }

    @PostMapping("/delete/{id}")
    public String deleteProduct(@PathVariable Integer id) {
        productRepository.deleteById(id);
        return "redirect:/all";
    }
}