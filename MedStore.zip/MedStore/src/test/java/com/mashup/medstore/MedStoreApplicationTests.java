package com.mashup.medstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
